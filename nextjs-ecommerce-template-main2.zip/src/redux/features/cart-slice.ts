// 📌 این فایل مربوط به مدیریت سبد خرید (Cart) با استفاده از Redux Toolkit است.
// در اینجا تمام اکشن‌ها (افزودن، حذف، آپدیت تعداد و خالی کردن سبد) و سلکتورهای مربوطه تعریف شده‌اند.

import { createSelector, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "../store";

// 🎯 تعریف نوع داده‌ها برای آیتم‌های داخل سبد خرید
type CartItem = {
  id: number; // آیدی محصول
  title: string; // نام محصول
  price: number; // قیمت اصلی محصول
  discountedPrice: number; // قیمت تخفیف خورده
  quantity: number; // تعداد محصول
  imgs?: {
    thumbnails: string[]; // عکس‌های کوچک
    previews: string[]; // عکس‌های پیش‌نمایش
  };
};

// 📦 استیت اولیه (سبد خرید در شروع خالی است)
type InitialState = {
  items: CartItem[];
};

const initialState: InitialState = {
  items: [],
};

// 🛒 ایجاد Slice مربوط به سبد خرید
export const cart = createSlice({
  name: "cart",
  initialState,
  reducers: {
    // ➕ اضافه کردن محصول به سبد خرید
    addItemToCart: (state, action: PayloadAction<CartItem>) => {
      const { id, title, price, quantity, discountedPrice, imgs } = action.payload;
      const existingItem = state.items.find((item) => item.id === id);

      if (existingItem) {
        // اگر محصول وجود داشت، فقط تعداد آن افزایش پیدا می‌کند
        existingItem.quantity += quantity;
      } else {
        // اگر محصول وجود نداشت، به آرایه اضافه می‌شود
        state.items.push({
          id,
          title,
          price,
          quantity,
          discountedPrice,
          imgs,
        });
      }
    },

    // ❌ حذف یک محصول خاص از سبد خرید
    removeItemFromCart: (state, action: PayloadAction<number>) => {
      const itemId = action.payload;
      state.items = state.items.filter((item) => item.id !== itemId);
    },

    // 🔄 تغییر تعداد یک محصول خاص
    updateCartItemQuantity: (state, action: PayloadAction<{ id: number; quantity: number }>) => {
      const { id, quantity } = action.payload;
      const existingItem = state.items.find((item) => item.id === id);

      if (existingItem) {
        existingItem.quantity = quantity;
      }
    },

    // 🧹 خالی کردن کل سبد خرید
    removeAllItemsFromCart: (state) => {
      state.items = [];
    },
  },
});

// 🔍 سلکتور برای گرفتن آیتم‌های سبد خرید
export const selectCartItems = (state: RootState) => state.cartReducer.items;

// 💰 سلکتور برای محاسبه مجموع قیمت نهایی سبد خرید
export const selectTotalPrice = createSelector([selectCartItems], (items) => {
  return items.reduce((total, item) => {
    return total + item.discountedPrice * item.quantity;
  }, 0);
});

// 📤 اکسپورت اکشن‌ها
export const {
  addItemToCart,
  removeItemFromCart,
  updateCartItemQuantity,
  removeAllItemsFromCart,
} = cart.actions;

// 📤 اکسپورت ریدوسر اصلی برای استفاده در Store
export default cart.reducer;
