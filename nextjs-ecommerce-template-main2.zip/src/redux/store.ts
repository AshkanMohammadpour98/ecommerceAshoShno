// 📌 این فایل "store" یا مرکز اصلی مدیریت Redux هست
// کاربرد: همه‌ی slice ها (سبد خرید، لیست علاقه‌مندی، جزئیات محصول و ...) رو به یکجا وصل می‌کنه

import { configureStore } from "@reduxjs/toolkit";

// 📦 ایمپورت کردن ریدیوسرهای مختلف که با createSlice ساختیم
import quickViewReducer from "./features/quickView-slice";
import cartReducer from "./features/cart-slice";
import wishlistReducer from "./features/wishlist-slice";
import productDetailsReducer from "./features/product-details";

import { TypedUseSelectorHook, useSelector } from "react-redux";

// 🛠️ ساخت استور اصلی با ترکیب همه‌ی reducer ها
export const store = configureStore({
  reducer: {
    quickViewReducer,       // مدیریت حالت "نمایش سریع محصول"
    cartReducer,            // مدیریت سبد خرید
    wishlistReducer,        // مدیریت لیست علاقه‌مندی‌ها
    productDetailsReducer,  // مدیریت جزئیات محصول
  },
});

// 📌 نوع (type) استیت کلی پروژه برای استفاده در تایپ‌اسکریپت
export type RootState = ReturnType<typeof store.getState>;

// 📌 نوع dispatch برای تایپ‌اسکریپت
export type AppDispatch = typeof store.dispatch;

// 🎯 یک هوک سفارشی برای گرفتن state ها به شکل تایپ شده
// به جای useSelector ساده از useAppSelector استفاده می‌کنیم
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
