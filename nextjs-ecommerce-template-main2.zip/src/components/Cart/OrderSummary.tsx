// 📌 این کامپوننت "جمع سفارش‌ها" را نمایش می‌دهد.
// کاربر می‌تواند لیست محصولات سبد خرید و جمع کل را مشاهده کرده و به صفحه پرداخت برود.

import { selectTotalPrice } from "@/redux/features/cart-slice";
import { useAppSelector } from "@/redux/store";
import React from "react";
import { useSelector } from "react-redux";

const OrderSummary = () => {
  // 📌 دریافت آیتم‌های سبد خرید از استیت ریداکس
  const cartItems = useAppSelector((state) => state.cartReducer.items);
  // 📌 دریافت مجموع قیمت کل سبد خرید
  const totalPrice = useSelector(selectTotalPrice);

  return (
    <div className="lg:max-w-[455px] w-full" dir="rtl">
      {/* 📌 باکس جمع سفارش‌ها */}
      <div className="bg-white shadow-1 rounded-[10px]">
        {/* 📌 هدر باکس */}
        <div className="border-b border-gray-3 py-5 px-4 sm:px-8.5">
          <h3 className="font-medium text-xl text-dark">جمع سفارش‌ها</h3>
        </div>

        <div className="pt-2.5 pb-8.5 px-4 sm:px-8.5">

          {/* 📌 عنوان ستون‌ها */}
          <div className="flex items-center justify-between py-5 border-b border-gray-3">
            <div>
              <h4 className="font-medium text-dark">محصول</h4>
            </div>
            <div>
              <h4 className="font-medium text-dark text-right">جمع جزء</h4>
            </div>
          </div>

          {/* 📌 رندر هر محصول در سبد خرید */}
          {cartItems.map((item, key) => (
            <div
              key={key}
              className="flex items-center justify-between py-5 border-b border-gray-3"
            >
              <div>
                <p className="text-dark">{item.title}</p>
              </div>
              <div>
                <p className="text-dark text-right">
                  {item.discountedPrice * item.quantity} تومان
                </p>
              </div>
            </div>
          ))}

          {/* 📌 جمع کل */}
          <div className="flex items-center justify-between pt-5">
            <div>
              <p className="font-medium text-lg text-dark">جمع کل</p>
            </div>
            <div>
              <p className="font-medium text-lg text-dark text-right">
                {totalPrice} تومان
              </p>
            </div>
          </div>

          {/* 📌 دکمه ادامه به صفحه پرداخت */}
          <button
            type="submit"
            className="w-full flex justify-center font-medium text-white bg-blue py-3 px-6 rounded-md ease-out duration-200 hover:bg-blue-dark mt-7.5"
          >
            ادامه به پرداخت
          </button>

        </div>
      </div>
    </div>
  );
};

export default OrderSummary;
