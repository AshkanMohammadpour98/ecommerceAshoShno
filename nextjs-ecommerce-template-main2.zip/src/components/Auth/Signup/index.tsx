// 📂 فایل: pages/signup/index.tsx
// این صفحه مربوط به "ثبت‌نام کاربر" هست و شامل فرم ایجاد حساب کاربری می‌باشد.

import Breadcrumb from "@/components/Common/Breadcrumb";
import Link from "next/link";
import React from "react";

const Signup = () => {
  return (
    <>
      {/* مسیر صفحه (breadcrumb) بالای فرم */}
      <Breadcrumb title={"ثبت‌نام"} pages={["ثبت‌نام"]} />

      {/* بخش اصلی فرم ثبت‌نام */}
      <section dir="rtl" className="overflow-hidden py-20 bg-gray-2">
        <div className="max-w-[1170px] w-full mx-auto px-4 sm:px-8 xl:px-0">
          <div className="max-w-[570px] w-full mx-auto rounded-xl bg-white shadow-1 p-4 sm:p-7.5 xl:p-11">
            
            {/* عنوان و توضیحات بالای فرم */}
            <div className="text-center mb-11">
              <h2 className="font-semibold text-xl sm:text-2xl xl:text-heading-5 text-dark mb-1.5">
                ایجاد حساب کاربری
              </h2>
              <p>لطفاً اطلاعات خود را وارد کنید</p>
            </div>

            {/* دکمه‌های ورود با شبکه‌های اجتماعی */}
            <div className="flex flex-col gap-4.5">
              <button className="flex justify-center items-center gap-3.5 rounded-lg border border-gray-300 bg-gray-100 p-3 ease-out duration-200 hover:bg-gray-200">
                {/* آیکون گوگل */}
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                  {/* ... (همون کد SVG گوگل) */}
                </svg>
                ثبت‌نام با گوگل
              </button>

              <button className="flex justify-center items-center gap-3.5 rounded-lg border border-gray-300 bg-gray-100 p-3 ease-out duration-200 hover:bg-gray-200">
                {/* آیکون گیت‌هاب */}
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                  {/* ... (همون کد SVG گیت‌هاب) */}
                </svg>
                ثبت‌نام با گیت‌هاب
              </button>
            </div>

            {/* خط جداکننده بین دکمه‌های اجتماعی و فرم */}
            <span className="relative z-1 block font-medium text-center mt-4.5">
              <span className="block absolute -z-1 left-0 top-1/2 h-px w-full bg-gray-300"></span>
              <span className="inline-block px-3 bg-white">یا</span>
            </span>

            {/* فرم ثبت‌نام */}
            <div className="mt-5.5">
              <form>
                {/* فیلد نام کامل */}
                <div className="mb-5">
                  <label htmlFor="name" className="block mb-2.5">
                    نام کامل <span className="text-red">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    placeholder="نام و نام خانوادگی خود را وارد کنید"
                    className="rounded-lg border border-gray-300 bg-gray-100 placeholder:text-dark-500 w-full py-3 px-5 outline-none duration-200 focus:border-transparent focus:shadow-input focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                {/* فیلد ایمیل */}
                <div className="mb-5">
                  <label htmlFor="email" className="block mb-2.5">
                    ایمیل <span className="text-red">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    placeholder="ایمیل خود را وارد کنید"
                    className="rounded-lg border border-gray-300 bg-gray-100 placeholder:text-dark-500 w-full py-3 px-5 outline-none duration-200 focus:border-transparent focus:shadow-input focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                {/* فیلد رمز عبور */}
                <div className="mb-5">
                  <label htmlFor="password" className="block mb-2.5">
                    رمز عبور <span className="text-red">*</span>
                  </label>
                  <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="رمز عبور خود را وارد کنید"
                    autoComplete="on"
                    className="rounded-lg border border-gray-300 bg-gray-100 placeholder:text-dark-500 w-full py-3 px-5 outline-none duration-200 focus:border-transparent focus:shadow-input focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                {/* فیلد تکرار رمز عبور */}
                <div className="mb-5.5">
                  <label htmlFor="re-type-password" className="block mb-2.5">
                    تکرار رمز عبور <span className="text-red">*</span>
                  </label>
                  <input
                    type="password"
                    name="re-type-password"
                    id="re-type-password"
                    placeholder="رمز عبور را دوباره وارد کنید"
                    autoComplete="on"
                    className="rounded-lg border border-gray-300 bg-gray-100 placeholder:text-dark-500 w-full py-3 px-5 outline-none duration-200 focus:border-transparent focus:shadow-input focus:ring-2 focus:ring-blue-200"
                  />
                </div>

                {/* دکمه ارسال فرم */}
                <button
                  type="submit"
                  className="w-full flex justify-center font-medium text-white bg-dark py-3 px-6 rounded-lg ease-out duration-200 hover:bg-blue mt-7.5"
                >
                  ایجاد حساب کاربری
                </button>

                {/* لینک ورود برای کاربرانی که حساب دارند */}
                <p className="text-center mt-6">
                  قبلاً حساب کاربری ساخته‌اید؟
                  <Link
                    href="/signin"
                    className="text-dark ease-out duration-200 hover:text-blue pr-2"
                  >
                    ورود به حساب
                  </Link>
                </p>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Signup;
