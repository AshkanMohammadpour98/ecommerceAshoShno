// ✅ این فایل مربوط به صفحه فروشگاه همراه با سایدبار هست
// این صفحه برای نمایش محصولات فروشگاه استفاده می‌شود و به کاربر امکان فیلتر کردن و جستجوی محصولات را می‌دهد.
// سایدبار شامل دسته‌بندی‌ها، فیلتر قیمت و ویژگی‌های دیگر است.

import React from "react";
import ShopWithSidebar from "@/components/ShopWithSidebar"; // 🛒 کامپوننت فروشگاه با سایدبار

// 📝 متادیتا (metadata) برای سئو و مرورگر
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "فروشگاه | آسو شنو", // 🏷️ عنوان فارسی و مناسب برای سئو
  description: "صفحه فروشگاه برای مشاهده و فیلتر محصولات",
  // 👉 میشه برای بهبود سئو، keywords یا openGraph هم اضافه کرد
};

// 📦 خود صفحه ShopWithSidebar
const ShopWithSidebarPage = () => {
  return (
    <main dir="rtl">
      {/* 🛒 نمایش محصولات فروشگاه به همراه سایدبار */}
      <ShopWithSidebar />
    </main>
  );
};

export default ShopWithSidebarPage;
