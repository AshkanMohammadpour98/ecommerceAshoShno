// ✅ این فایل مربوط به صفحه علاقه‌مندی‌ها (Wishlist) است
// در این صفحه محصولات مورد علاقه کاربران نمایش داده می‌شوند و کاربر می‌تواند آن‌ها را به سبد خرید اضافه یا حذف کند.

import React from "react";
import { Wishlist } from "@/components/Wishlist"; // 🔑 کامپوننت نمایش لیست علاقه‌مندی‌ها

import { Metadata } from "next";

// 📝 متادیتا (metadata) برای سئو و مرورگر
export const metadata: Metadata = {
  title: "علاقه‌مندی‌ها | آسو شنو", // 🏷️ عنوان فارسی
  description: "صفحه محصولات مورد علاقه کاربران برای مشاهده و مدیریت",
};

const WishlistPage = () => {
  return (
    <main dir="rtl">
      {/* 🔑 نمایش کامپوننت علاقه‌مندی‌ها */}
      <Wishlist />
    </main>
  );
};

export default WishlistPage;
