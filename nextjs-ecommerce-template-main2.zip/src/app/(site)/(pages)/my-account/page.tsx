// ✅ این فایل مربوط به صفحه "اکانت من" هست
// این صفحه برای مشاهده و مدیریت اطلاعات کاربر استفاده می‌شود.
// کاربر می‌تواند اطلاعات پروفایل، سفارش‌ها و دیگر جزئیات حساب خود را مشاهده و مدیریت کند.

import React from "react";
import MyAccount from "@/components/MyAccount"; // 👤 کامپوننت اصلی اکانت

// 📝 متادیتا (metadata) برای سئو و مرورگر
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "اکانت من | آسو شنو", // 🏷️ عنوان فارسی و مناسب برای سئو
  description: "صفحه اکانت کاربری برای مدیریت اطلاعات و سفارش‌ها",
  // 👉 میشه برای بهبود سئو، keywords یا openGraph هم اضافه کرد
};

// 📦 خود صفحه MyAccount
const MyAccountPage = () => {
  return (
    <main dir="rtl">
      {/* 👤 نمایش بخش اکانت کاربر */}
      <MyAccount />
    </main>
  );
};

export default MyAccountPage;
