// 📌 این فایل مربوط به صفحه "تسویه حساب (Checkout)" هست
// کاربرد: وقتی کاربر می‌خواد خرید خودش رو نهایی کنه، به این صفحه هدایت می‌شه

import React from "react";
import Checkout from "@/components/Checkout"; // 💳 ایمپورت کامپوننت اصلی تسویه‌حساب

// 📝 متادیتا (metadata) برای سئو و اطلاعات صفحه
// نمایش عنوان و توضیحات در مرورگر و موتورهای جستجو
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "تسویه حساب | فروشگاه اینترنتی NextCommerce",
  description: "این صفحه مخصوص وارد کردن اطلاعات پرداخت و نهایی کردن خرید است",
  // 📌 می‌تونی بخش‌های دیگه مثل keywords یا openGraph هم اضافه کنی
};

// 📦 خود کامپوننت صفحه تسویه حساب
const CheckoutPage = () => {
  return (
    <main dir="rtl">
      {/* 💳 نمایش کامپوننت Checkout که شامل فرم پرداخت و اطلاعات کاربر است */}
      <Checkout />
    </main>
  );
};

export default CheckoutPage;
