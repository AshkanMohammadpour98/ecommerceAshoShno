import Home from "@/components/Home";
import { Metadata } from "next";

export const metadata: Metadata = {
  title:  "آسو شنو",
  description: "فروشگاه و تعمیرات  موبایل تبلت و کامپیوتر لپ تاپ آسو شنو",
  // other metadata
};

export default function HomePage() {
  return (
    <>
      <Home />
    </>
  );
}
