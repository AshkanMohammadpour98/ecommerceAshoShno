"use client";

import { Swiper, SwiperSlide } from "swiper/react";
import { useCallback, useRef } from "react";
import testimonialsData from "./testimonialsData";
import Image from "next/image";

// Import Swiper styles
import "swiper/css/navigation";
import "swiper/css";
import SingleItem from "./SingleItem";

// کامپوننت اصلی Testimonials
const Testimonials = () => {
  const sliderRef = useRef<any>(null);

  // تابع حرکت اسلایدر به عقب
  const handlePrev = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slidePrev();
  }, []);

  // تابع حرکت اسلایدر به جلو
  const handleNext = useCallback(() => {
    if (!sliderRef.current) return;
    sliderRef.current.swiper.slideNext();
  }, []);

  return (
    <section className="overflow-hidden pb-16.5">
      <div className="max-w-[1170px] w-full mx-auto px-4 sm:px-8 xl:px-0">
        <div className="swiper testimonial-carousel common-carousel p-5">
          {/* بخش عنوان و دکمه‌های ناوبری اسلایدر */}
          <div className="mb-10 flex items-center justify-between">
            <div>
              {/* آیکون و عنوان بخش */}
              <span className="flex items-center gap-2.5 font-medium text-dark mb-1.5">
                <Image
                  src="/images/icons/icon-08.svg"
                  alt="آیکون"
                  width={17}
                  height={17}
                />
                نظرات کاربران
              </span>
              <h2 className="font-semibold text-xl xl:text-heading-5 text-dark">
                بازخورد کاربران
              </h2>
            </div>

            {/* دکمه‌های قبلی و بعدی اسلایدر */}
            {/* دکمه‌های قبلی و بعدی اسلایدر */}
<div className="flex items-center gap-3">
  {/* فلش قبلی → سمت راست */}
  <div onClick={handlePrev} className="swiper-button-prev cursor-pointer">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M8 6L16 12L8 18" stroke="#3C50E0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>

  {/* فلش بعدی → سمت چپ */}
  <div onClick={handleNext} className="swiper-button-next cursor-pointer">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 6L8 12L16 18" stroke="#3C50E0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>
</div>

          </div>

          {/* اسلایدر Swiper */}
          <Swiper
            ref={sliderRef}
            slidesPerView={3}
            spaceBetween={20}
            breakpoints={{
              0: { slidesPerView: 1 },
              1000: { slidesPerView: 2 },
              1200: { slidesPerView: 3 },
            }}
          >
            {testimonialsData.map((item, key) => (
              <SwiperSlide key={key}>
                <SingleItem testimonial={item} />
              </SwiperSlide>
            ))}
          </Swiper>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
