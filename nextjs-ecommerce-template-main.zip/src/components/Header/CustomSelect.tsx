import React, { useState, useEffect } from "react";

// کامپوننت CustomSelect: یک سلکتور سفارشی برای دسته‌بندی‌ها
const CustomSelect = ({ options }) => {
  // مدیریت باز یا بسته بودن منو
  const [isOpen, setIsOpen] = useState(false);
  // مدیریت گزینه انتخاب شده
  const [selectedOption, setSelectedOption] = useState(options[0]);

  // تغییر وضعیت باز و بسته شدن منو
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  // وقتی یک گزینه انتخاب می‌شود
  const handleOptionClick = (option) => {
    setSelectedOption(option); // گزینه جدید انتخاب می‌شود
    toggleDropdown(); // منو بسته می‌شود
  };

  useEffect(() => {
    // بستن منو وقتی کاربر بیرون از آن کلیک می‌کند
    function handleClickOutside(event) {
      if (!event.target.closest(".dropdown-content")) {
        setIsOpen(false); // فقط منو بسته شود، نه باز و بسته شدن معکوس
      }
    }

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    // پاکسازی event listener هنگام unmount
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  return (
    <div
      className="dropdown-content custom-select relative"
      style={{ width: "200px" }}
    >
      {/* بخش انتخاب شده */}
      <div
        className={`select-selected whitespace-nowrap ${
          isOpen ? "select-arrow-active" : ""
        }`}
        onClick={toggleDropdown}
      >
        {selectedOption.label}
      </div>

      {/* لیست گزینه‌ها */}
      <div className={`select-items ${isOpen ? "" : "select-hide"}`}>
        {/* skip اولین و آخرین گزینه (مثلاً placeholder و همه) */}
        {options.slice(1, -1).map((option, index) => (
          <div
            key={index}
            onClick={() => handleOptionClick(option)}
            className={`select-item ${
              selectedOption === option ? "same-as-selected" : ""
            }`}
          >
            {option.label}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CustomSelect;
