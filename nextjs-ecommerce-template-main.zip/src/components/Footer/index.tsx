import React from "react";

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="overflow-hidden" dir="rtl">
      <div className="max-w-[1170px] mx-auto px-4 sm:px-8 xl:px-0">
        {/* محتوای فوتر */}
        <div className="flex flex-wrap xl:flex-nowrap gap-10 xl:gap-19 xl:justify-between pt-17.5 xl:pt-22.5 pb-10 xl:pb-15">

          {/* ستون ۱ - پشتیبانی */}
          <div className="max-w-[330px] w-full">
            <h2 className="mb-7.5 text-custom-1 font-medium text-dark">
              پشتیبانی و ارتباط با ما
            </h2>
            <ul className="flex flex-col gap-3">
              <li className="flex gap-4.5">
                <span className="flex-shrink-0">
                  📍
                </span>
                اشنویه خیابان انقلاب، فروشگاه اسو شنو
              </li>
              <li>
                <a href="tel:+982112345678" className="flex items-center gap-4.5">
                  ☎
                  021-12345678
                </a>
              </li>
              <li>
                <a href="mailto:info@example.com" className="flex items-center gap-4.5">
                  ✉
                  info@example.com
                </a>
              </li>
            </ul>

            {/* شبکه‌های اجتماعی */}
            <div className="flex items-center gap-4 mt-7.5">
              <a href="#" aria-label="Facebook" className="hover:text-blue">🌐</a>
              <a href="#" aria-label="Twitter" className="hover:text-blue">🐦</a>
              <a href="#" aria-label="Instagram" className="hover:text-blue">📸</a>
            </div>
          </div>

          {/* ستون ۲ - لینک‌های سریع */}
          <div>
            <h2 className="mb-7.5 text-custom-1 font-medium text-dark">
              لینک‌های سریع
            </h2>
            <ul className="flex flex-col gap-3">
              <li>
                <a href="/" className="hover:text-blue">خانه</a>
              </li>
              <li>
                <a href="/shop" className="hover:text-blue">فروشگاه</a>
              </li>
              <li>
                <a href="/about" className="hover:text-blue">درباره ما</a>
              </li>
              <li>
                <a href="/contact" className="hover:text-blue">تماس با ما</a>
              </li>
              <li>
                <a href="/faq" className="hover:text-blue">سوالات متداول</a>
              </li>
            </ul>
          </div>

          {/* ستون ۳ - درباره ما */}
          <div className="max-w-[330px]">
            <h2 className="mb-7.5 text-custom-1 font-medium text-dark">
              درباره ما
            </h2>
            <p className="text-gray-600 leading-relaxed">
              فروشگاه ما آسو شنو ارائه‌دهنده‌ی خدمات خرید، فروش و تعمیر انواع لپ‌تاپ،
              موبایل و هدفون است. با تیمی متخصص و پشتیبانی قوی، تجربه‌ای مطمئن و
              آسان برای مشتریان فراهم می‌کنیم.
            </p>
          </div>
        </div>

        {/* کپی‌رایت */}
        <div className="border-t border-gray-200 py-4 text-center text-sm text-gray-500">
          © {year} همه حقوق محفوظ است | طراحی و توسعه با ❤️ توسط تیم ما
        </div>
      </div>
    </footer>
  );
};

export default Footer;
