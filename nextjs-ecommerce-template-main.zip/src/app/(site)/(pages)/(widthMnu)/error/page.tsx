// ⚠️ این فایل مربوط به صفحه "خطا (Error Page)" هست
// کاربرد: وقتی کاربر وارد مسیری بشه که وجود نداره یا مشکلی پیش بیاد، این صفحه نمایش داده می‌شه

import React from "react";
import Error from "@/components/Error"; // 🚨 کامپوننت نمایش پیام خطا

// 📝 متادیتا (metadata) برای سئو و اطلاعات صفحه
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "صفحه خطا | آسو شنو", // 🏷️ عنوان صفحه خطا
  description: "این صفحه برای نمایش پیام‌های خطا و مسیرهای نامعتبر استفاده می‌شود",
  // 👉 می‌تونی برای بهبود سئو، keywords یا openGraph هم اضافه کنی
};

// 📦 خود کامپوننت صفحه خطا
const ErrorPage = () => {
  return (
    <main dir="rtl">
      {/* 🚨 نمایش کامپوننت Error که پیام مناسب به کاربر نشون می‌ده */}
      <Error />
    </main>
  );
};

export default ErrorPage;
