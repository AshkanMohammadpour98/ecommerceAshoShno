// ✅ این فایل مربوط به صفحه فروشگاه بدون سایدبار است
// این صفحه برای نمایش تمامی محصولات فروشگاه بدون استفاده از سایدبار استفاده می‌شود.
// کاربر فقط محصولات را مشاهده می‌کند و فیلترها یا دسته‌بندی‌ها در سایدبار نیستند.

import React from "react";
import ShopWithoutSidebar from "@/components/ShopWithoutSidebar"; // 🛒 کامپوننت فروشگاه بدون سایدبار

// 📝 متادیتا (metadata) برای سئو و مرورگر
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "فروشگاه | آسو شنو", // 🏷️ عنوان فارسی و مناسب برای سئو
  description: "صفحه فروشگاه برای مشاهده محصولات بدون سایدبار",
  // 👉 می‌توان برای بهبود سئو، keywords یا openGraph هم اضافه کرد
};

// 📦 خود صفحه ShopWithoutSidebar
const ShopWithoutSidebarPage = () => {
  return (
    <main dir="rtl">
      {/* 🛒 نمایش محصولات فروشگاه بدون سایدبار */}
      <ShopWithoutSidebar />
    </main>
  );
};

export default ShopWithoutSidebarPage;
