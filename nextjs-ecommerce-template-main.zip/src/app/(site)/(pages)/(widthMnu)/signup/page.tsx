// ✅ این فایل مربوط به صفحه ثبت‌نام (Signup) است
// این صفحه برای ثبت حساب کاربری جدید توسط کاربران استفاده می‌شود.

import React from "react";
import Signup from "@/components/Auth/Signup"; // 🔑 کامپوننت فرم ثبت‌نام

// 📝 متادیتا (metadata) برای سئو و مرورگر
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "ثبت‌نام | آسو شنو", // 🏷️ عنوان فارسی
  description: "صفحه ثبت‌نام کاربران برای ایجاد حساب کاربری جدید",
};

const SignupPage = () => {
  return (
    <main dir="rtl">
      {/* 🔑 نمایش فرم ثبت‌نام */}
      <Signup />
    </main>
  );
};

export default SignupPage;
