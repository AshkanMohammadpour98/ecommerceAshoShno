export default function ShopCategorie(){
    return(
        <h1>لیست همه دسته بندی ها</h1>
    )
}