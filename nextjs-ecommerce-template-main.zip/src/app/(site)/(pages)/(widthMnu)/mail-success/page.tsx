// ✅ این فایل مربوط به صفحه "موفقیت در ارسال ایمیل" هست
// زمانی که کاربر فرم تماس یا ثبت‌نام رو پر می‌کنه و ایمیل با موفقیت ارسال می‌شه، این صفحه نمایش داده میشه.

import React from "react";
import MailSuccess from "@/components/MailSuccess"; // 📩 کامپوننت نمایش پیام موفقیت

// 📝 متادیتا (metadata) برای سئو و مرورگر
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "ایمیل با موفقیت ارسال شد | آسو شنو", // 🏷️ عنوان فارسی و مناسب برای سئو
  description:
    "این صفحه زمانی نمایش داده می‌شود که ارسال ایمیل با موفقیت انجام شده باشد.",
  // 👉 میشه برای بهبود سئو، keywords یا openGraph هم اضافه کرد
};

// 📦 خود صفحه Mail Success
const MailSuccessPage = () => {
  return (
    <main dir="rtl">
      {/* 📩 نمایش پیام موفقیت ارسال ایمیل */}
      <MailSuccess />
    </main>
  );
};

export default MailSuccessPage;
