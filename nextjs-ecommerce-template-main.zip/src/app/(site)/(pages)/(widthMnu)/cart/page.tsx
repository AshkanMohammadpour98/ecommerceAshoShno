// 📌 این فایل مربوط به صفحه "سبد خرید" در پروژه Next.js هست
// کاربرد: این صفحه همون صفحه‌ایه که کاربر محصولات اضافه‌شده به سبد خرید رو می‌بینه

import React from "react";
import Cart from "@/components/Cart"; // 🛒 ایمپورت کامپوننت اصلی سبد خرید

// 📝 متادیتا (metadata) برای سئو و اطلاعات صفحه
// وقتی کاربر توی مرورگر باز می‌کنه یا گوگل ایندکس می‌کنه، این title و description نمایش داده می‌شه
import { Metadata } from "next";
export const metadata: Metadata = {
  title: "سبد خرید | فروشگاه آسو شنو",
  description: "این صفحه مخصوص نمایش محصولات موجود در سبد خرید است",
  // 📌 می‌تونی کلیدهای دیگه مثل keywords یا openGraph هم اضافه کنی
};

// 📦 خود کامپوننت صفحه سبد خرید
const CartPage = () => {
  return (
    <>
      {/* 🛒 نمایش کامپوننت Cart که محتویات سبد خرید رو نشون میده */}
      <Cart />
    </>
  );
};

export default CartPage;
