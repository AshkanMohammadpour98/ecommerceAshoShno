export default function EditQrCodes(){

    return (
        <h1>
            EditQrCodes لیست محصولاتی که Qrcode دارند
        </h1>
    )
}