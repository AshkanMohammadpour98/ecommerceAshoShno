// ✅ این فایل مربوط به صفحه گرید بلاگ است
// در این صفحه تمام مقالات بلاگ به صورت گرید نمایش داده می‌شوند.

import React from "react";
import BlogGrid from "@/components/BlogGrid"; // 🔑 کامپوننت گرید بلاگ

import { Metadata } from "next";

// 📝 متادیتا (metadata) برای سئو و مرورگر
export const metadata: Metadata = {
  title: "گرید بلاگ | آسو شنو", // 🏷️ عنوان فارسی
  description: "صفحه نمایش تمام مقالات بلاگ به صورت گرید",
};

const BlogGridPage = () => {
  return (
    <main dir="rtl">
      {/* 🔑 نمایش کامپوننت گرید بلاگ */}
      <BlogGrid />
    </main>
  );
};

export default BlogGridPage;
