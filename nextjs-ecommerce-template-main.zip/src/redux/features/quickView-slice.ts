// 📌 این فایل مربوط به مدیریت بخش "مشاهده سریع محصول" (Quick View) در Redux است.
// کاربرد: وقتی کاربر روی دکمه "مشاهده سریع" کلیک می‌کند، اطلاعات محصول انتخابی
// در استیت ذخیره می‌شود و برای نمایش در مودال یا پنجره پاپ‌آپ استفاده خواهد شد.

import { createSlice } from "@reduxjs/toolkit";
import { Product } from "@/types/product";

// 🎯 نوع استیت اولیه (اطلاعات محصول)
type InitialState = {
  value: Product;
};

// 📦 مقدار اولیه استیت (محصول خالی)
const initialState = {
  value: {
    title: "", // عنوان محصول
    reviews: 0, // تعداد نظرات
    price: 0, // قیمت اصلی
    discountedPrice: 0, // قیمت با تخفیف
    img: "", // تصویر اصلی
    id: 0, // شناسه محصول
    images: [], // لیست تصاویر
    imgs: { thumbnails: [], previews: [] }, // تصاویر بندانگشتی و پیش‌نمایش
  } as Product,
} as InitialState;

// 🛠️ ایجاد Slice برای مدیریت Quick View
export const quickView = createSlice({
  name: "quickView",
  initialState,
  reducers: {
    // 🔄 آپدیت اطلاعات محصول در Quick View
    updateQuickView: (_, action) => {
      return {
        value: {
          ...action.payload, // جایگزینی اطلاعات جدید محصول
        },
      };
    },

    // ♻️ ریست کردن اطلاعات Quick View (برگشت به حالت خالی)
    resetQuickView: () => {
      return {
        value: initialState.value,
      };
    },
  },
});

// 📤 اکسپورت اکشن‌ها
export const { updateQuickView, resetQuickView } = quickView.actions;

// 📤 اکسپورت ریدوسر اصلی برای استفاده در Store
export default quickView.reducer;
