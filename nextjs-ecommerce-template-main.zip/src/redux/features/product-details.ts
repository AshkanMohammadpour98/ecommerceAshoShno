// 📌 این فایل مربوط به مدیریت جزئیات محصول (Product Details) با استفاده از Redux Toolkit است.
// کاربرد: وقتی کاربر روی یک محصول کلیک می‌کند، اطلاعات آن محصول (مثل عنوان، قیمت، عکس‌ها) در استیت ذخیره می‌شود
// و در صفحه جزئیات محصول یا بخش‌های دیگر پروژه قابل دسترس خواهد بود.

import { createSlice } from "@reduxjs/toolkit";
import { Product } from "@/types/product";

// 🎯 نوع استیت اولیه (اطلاعات محصول)
type InitialState = {
  value: Product;
};

// 📦 مقدار اولیه استیت (محصول خالی)
const initialState = {
  value: {
    title: "", // عنوان محصول
    reviews: 0, // تعداد نظرات
    price: 0, // قیمت اصلی
    discountedPrice: 0, // قیمت بعد از تخفیف
    img: "", // تصویر اصلی
    images: [], // لیست تصاویر
    id: 0, // شناسه محصول
    imgs: { thumbnails: [], previews: [] }, // تصاویر کوچک و پیش‌نمایش
  },
} as InitialState;

// 🛠️ ایجاد Slice برای مدیریت جزئیات محصول
export const productDetails = createSlice({
  name: "productDetails",
  initialState,
  reducers: {
    // 🔄 آپدیت اطلاعات محصول
    updateproductDetails: (_, action) => {
      return {
        value: {
          ...action.payload, // جایگزینی اطلاعات جدید محصول
        },
      };
    },
  },
});

// 📤 اکسپورت اکشن‌ها
export const { updateproductDetails } = productDetails.actions;

// 📤 اکسپورت ریدوسر اصلی برای استفاده در Store
export default productDetails.reducer;
