export type Category = {
  name: string;
  id: number;
  img: string;
};
